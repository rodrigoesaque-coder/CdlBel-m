# CDL Belém — Certificação Digital (versão estática para GitHub Pages)

Site 100% estático: só HTML, CSS e um JavaScript pequeno. Não precisa de
Node, npm, terminal nem build — dá pra publicar inteiro pela interface web
do GitHub, sem usar comando nenhum.

---

## 1. Criar sua conta no GitHub

1. Acesse **https://github.com/signup** e crie uma conta gratuita
   (e-mail, senha, nome de usuário).
2. Confirme o e-mail que o GitHub te enviar.

## 2. Criar o repositório e subir os arquivos (sem terminal)

1. Logado no GitHub, clique no **+** no canto superior direito → **"New
   repository"**.
2. Dê um nome, por exemplo `cdl-belem-site`. Deixe marcado como
   **Public** (o plano gratuito do GitHub Pages exige repositório público).
3. Não marque nenhuma opção de "Add a README" — deixe o repositório vazio.
   Clique em **"Create repository"**.
4. Na página do repositório recém-criado, clique no link **"uploading an
   existing file"** (aparece no meio da página, em "Quick setup").
5. Abra a pasta `cdl-belem-netlify` no seu computador, **selecione todos os
   arquivos e pastas dentro dela** (Ctrl+A) e arraste para a área de upload
   do GitHub. Espere o upload de todos os arquivos terminar.
6. Role até o final da página e clique em **"Commit changes"**.

## 3. Ativar o GitHub Pages

1. No repositório, clique em **"Settings"** (aba no topo).
2. No menu à esquerda, clique em **"Pages"**.
3. Em **"Build and deployment" → "Branch"**, escolha **`main`** e a pasta
   **`/ (root)`**. Clique em **"Save"**.
4. Espere cerca de 1 minuto e recarregue a página — vai aparecer um link
   verde do tipo `https://seu-usuario.github.io/cdl-belem-site/`.
5. Abra esse link — o site já está no ar, com HTTPS automático, acessível
   de qualquer lugar.

> Repare que o link tem `/cdl-belem-site/` no final (o nome do
> repositório). Isso muda quando você conectar um domínio próprio no
> passo 5 — o domínio final não vai ter esse sufixo.

## 4. Editando o conteúdo depois

Não tem um painel visual — a edição é direto nos arquivos:

1. No repositório do GitHub, clique no arquivo que quer editar (ex.:
   `index.html`).
2. Clique no ícone de lápis (**"Edit this file"**).
3. Faça a alteração, role até o fim e clique em **"Commit changes"**.
4. Em cerca de 1 minuto o site atualiza sozinho no ar.

## 5. Domínio próprio (.com.br) — quando você registrar

Você ainda não registrou o domínio, então guarde este passo a passo pra
quando tiver o nome escolhido.

### 5.1 Registrar o domínio

Acesse **https://registro.br**, escolha um nome disponível (ex.:
`certificadodigitalcdlbelem.com.br`) e registre. Custa **R$ 40/ano**, fixo.

### 5.2 Criar o arquivo CNAME no repositório

1. No repositório do GitHub, clique em **"Add file" → "Create new file"**.
2. No nome do arquivo, digite exatamente: `CNAME` (sem extensão, tudo
   maiúsculo).
3. No conteúdo do arquivo, escreva **só o domínio**, sem `http://` nem
   `www`, por exemplo:
   ```
   certificadodigitalcdlbelem.com.br
   ```
4. Clique em **"Commit changes"**.

### 5.3 Configurar o DNS no registro.br

No painel do registro.br, vá em **"Meus domínios" → seu domínio → "Editar
zona DNS"** e cadastre estes registros (valores oficiais do GitHub Pages):

| Tipo  | Nome/Host | Valor |
|-------|-----------|-------|
| A     | @         | 185.199.108.153 |
| A     | @         | 185.199.109.153 |
| A     | @         | 185.199.110.153 |
| A     | @         | 185.199.111.153 |
| CNAME | www       | seu-usuario.github.io |

(troque `seu-usuario` pelo seu nome de usuário real do GitHub)

### 5.4 Confirmar no GitHub

1. Volte em **Settings → Pages** no repositório.
2. Em **"Custom domain"**, digite o domínio e clique em **"Save"**.
3. Espere a propagação do DNS (de minutos a algumas horas).
4. Quando o GitHub reconhecer o domínio, marque a opção **"Enforce
   HTTPS"** — o certificado é emitido automaticamente pelo GitHub (via
   Let's Encrypt), sem custo.
5. Atualize as ocorrências de `SEU-DOMINIO-AQUI.com.br` dentro de
   `index.html`, `robots.txt` e `sitemap.xml` pelo domínio real.

## 6. O que muda em relação à versão para Netlify

- O formulário de contato agora só usa JavaScript: ele monta a mensagem e
  leva direto pro WhatsApp. Não existe mais o registro automático das
  mensagens em um painel (isso era um recurso específico do Netlify Forms,
  que não existe no GitHub Pages) — o WhatsApp continua sendo o canal de
  registro do contato.
- O arquivo `_headers` (cabeçalhos de segurança) é específico do Netlify e
  **não tem efeito no GitHub Pages** — ele fica no projeto sem função. Se
  no futuro você quiser cabeçalhos de segurança customizados no GitHub
  Pages, isso exige um serviço extra na frente (ex.: Cloudflare), já que o
  GitHub Pages puro não permite configurar isso.
- A página `obrigado.html` também não é mais usada automaticamente (o
  formulário vai direto pro WhatsApp), mas continua no projeto sem
  problema.

## 7. O que confirmar antes de divulgar o site

1. Números de WhatsApp e telefones (procure `EDITE AQUI` nos arquivos).
2. Preços da seção "Valores".
3. Logo oficial da CDL Belém (hoje é uma ilustração própria).
4. Revisão jurídica das páginas de Política de Privacidade, Cookies e
   Termos de Uso.

## 8. Estrutura de arquivos

```
cdl-belem-netlify/
├── index.html
├── politica-de-privacidade.html
├── politica-de-cookies.html
├── termos-de-uso.html
├── obrigado.html          (não usado automaticamente, mantido por segurança)
├── style.css
├── script.js
├── images/
├── favicon.svg
├── robots.txt
└── sitemap.xml
```

---

### Se um dia quiser voltar pro Netlify

O projeto continua compatível — é só arrastar a mesma pasta em
app.netlify.com/drop novamente. O único recurso que só funciona lá é o
registro automático das mensagens do formulário em um painel (Netlify
Forms); no GitHub Pages, o WhatsApp já cumpre esse papel.
