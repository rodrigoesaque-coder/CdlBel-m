// CDL Belém — Certificação Digital — comportamento do site estático
// Sem frameworks, sem build. Apenas: menu mobile, sombra no header ao rolar,
// e o ano atual no rodapé.

(function () {
  var header = document.querySelector(".site-header");
  var hamburger = document.querySelector(".hamburger");
  var mobileMenu = document.querySelector(".mobile-menu");

  function setMenu(open) {
    if (!mobileMenu || !hamburger) return;
    mobileMenu.classList.toggle("is-open", open);
    hamburger.setAttribute("aria-expanded", open ? "true" : "false");
    document.body.style.overflow = open ? "hidden" : "";
    hamburger.innerHTML = open
      ? '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" stroke="#0A2647" stroke-width="2" stroke-linecap="round"/></svg>'
      : '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16" stroke="#0A2647" stroke-width="2" stroke-linecap="round"/></svg>';
  }

  if (hamburger) {
    hamburger.addEventListener("click", function () {
      var isOpen = mobileMenu.classList.contains("is-open");
      setMenu(!isOpen);
    });
  }

  document.querySelectorAll(".mobile-menu a").forEach(function (link) {
    link.addEventListener("click", function () { setMenu(false); });
  });

  function onScroll() {
    if (!header) return;
    header.style.boxShadow = window.scrollY > 8 ? "0 1px 0 rgba(10,38,71,.06)" : "none";
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  var yearEls = document.querySelectorAll("[data-current-year]");
  yearEls.forEach(function (el) { el.textContent = new Date().getFullYear(); });

  // --------------------------------------------------------------------
  // Formulário de contato: envia para o Netlify Forms (fica registrado
  // no painel) e, em seguida, leva o visitante direto para o WhatsApp já
  // com uma mensagem pronta, montada com os dados que ele preencheu.
  // --------------------------------------------------------------------
  var WHATSAPP_NUMBER = "5591984069203"; // EDITE AQUI se o número mudar

  var contactForm = document.querySelector('form[name="contato"]');
  if (contactForm) {
    contactForm.addEventListener("submit", function (event) {
      event.preventDefault();

      var formData = new FormData(contactForm);

      // Honeypot: se o campo-armadilha veio preenchido, é bot — ignora.
      if (formData.get("bot-field")) return;

      var submitBtn = contactForm.querySelector('button[type="submit"]');
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = "Enviando...";
      }

      var name = (formData.get("name") || "").toString().trim();
      var email = (formData.get("email") || "").toString().trim();
      var phone = (formData.get("phone") || "").toString().trim();
      var doc = (formData.get("document") || "").toString().trim();
      var certType = (formData.get("certificateType") || "").toString().trim();
      var message = (formData.get("message") || "").toString().trim();

      var lines = [
        "Olá! Vim pelo site da CDL Belém e gostaria de solicitar atendimento.",
        "",
        "Nome: " + name,
        "Telefone: " + phone,
        "E-mail: " + email,
        "Tipo de certificado: " + (certType || "não informado"),
      ];
      if (doc) lines.push("CPF/CNPJ: " + doc);
      lines.push("", "Mensagem: " + message);

      var whatsappUrl =
        "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encodeURIComponent(lines.join("\n"));

      // Monta o corpo no formato que o Netlify Forms espera (urlencoded)
      var encodedPairs = [];
      formData.forEach(function (value, key) {
        encodedPairs.push(encodeURIComponent(key) + "=" + encodeURIComponent(value));
      });

      fetch("/", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: encodedPairs.join("&"),
      })
        .catch(function () {
          // mesmo se o registro no Netlify falhar, o atendimento não pode travar
        })
        .finally(function () {
          window.location.href = whatsappUrl;
        });
    });
  }

  // --------------------------------------------------------------------
  // Botões "Solicitar este plano" (seção Valores): em vez de ir direto
  // pro WhatsApp, descem até o formulário e já deixam o campo "Tipo de
  // certificado" selecionado com o plano escolhido, com um destaque
  // visual rápido pra confirmar que pegou certo.
  // --------------------------------------------------------------------
  var planButtons = document.querySelectorAll("[data-plan]");
  var certificateSelect = document.getElementById("certificateType");

  planButtons.forEach(function (btn) {
    btn.addEventListener("click", function () {
      if (!certificateSelect) return;
      var plan = btn.getAttribute("data-plan");

      var matched = false;
      Array.prototype.forEach.call(certificateSelect.options, function (opt) {
        if (opt.value === plan || opt.textContent.trim() === plan) {
          certificateSelect.value = opt.value;
          matched = true;
        }
      });
      if (!matched) return;

      certificateSelect.classList.add("field-highlight");
      setTimeout(function () {
        certificateSelect.classList.remove("field-highlight");
      }, 2200);
    });
  });
})();
