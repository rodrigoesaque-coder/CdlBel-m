# CDL Belém — Certificação Digital (versão estática para Netlify)

Esta é uma versão **100% estática** do site: só HTML, CSS e um JavaScript
pequeno. **Não precisa de Node, npm, terminal nem build** — é a forma mais
simples de colocar o site no ar, direto do Netlify.

---

## 1. Publicar o site (leva ~2 minutos, sem terminal)

1. Acesse **https://app.netlify.com/drop** no navegador (pode ser pelo
   próprio computador; não precisa de conta ainda para testar).
2. Arraste a **pasta inteira** `cdl-belem-netlify` (esta pasta, com todos os
   arquivos dentro) para a área indicada na página.
3. Em poucos segundos o Netlify publica o site e te dá um link, algo como
   `https://nome-aleatorio-123.netlify.app`.
4. Abra esse link — já é o site completo, com **HTTPS automático**,
   acessível de qualquer wifi, dados móveis, celular, notebook ou tablet.
5. Para editar o conteúdo depois (preços, telefone, endereço), você pode
   arrastar a pasta atualizada de novo na mesma tela, **ou** criar uma conta
   gratuita no Netlify (recomendado) para ter um painel permanente e poder
   reeditar quando quiser — veja o passo 2.

> Esse link `.netlify.app` já é público e funciona 24 horas por dia — o
> Netlify hospeda o site para você, seu computador não precisa ficar ligado.

## 2. Criar conta (recomendado, para poder gerenciar o site depois)

1. Ainda em app.netlify.com, clique em **"Sign up"** (pode entrar com
   Google, GitHub ou e-mail).
2. Depois de logado, vá em **"Sites"** → o site que você publicou por
   drag-and-drop vai aparecer lá (ou publique de novo já logado, arrastando
   a pasta na tela inicial).
3. Com a conta criada, você pode:
   - Trocar o nome do site (em **Site settings → Change site name**), o que
     muda o link para algo como `https://cdlbelem-certificacaodigital.netlify.app`.
   - Ver as mensagens recebidas pelo formulário de contato (seção **Forms**).
   - Conectar o domínio `.com.br` (passo 4).

## 3. Receber os e-mails do formulário de contato

O formulário já funciona sem nenhuma configuração — ele usa o **Netlify
Forms**, que é automático. Mas por padrão as respostas só ficam visíveis no
painel do Netlify; para receber por e-mail:

1. No painel do site, vá em **Forms** (ou **Site settings → Forms →
   Form notifications**).
2. Clique em **"Add notification" → "Email notification"**.
3. Coloque o e-mail `certificacaodigital@cdlbelem.com.br` (ou outro) e
   salve.
4. Pronto — a partir daí, toda vez que alguém preencher o formulário do
   site, esse e-mail recebe uma notificação automática.

## 4. Domínio próprio (.com.br) e HTTPS

### 4.1 Sugestões de domínio

Não verifiquei disponibilidade real (não tenho ferramenta de consulta de
domínios). Confira em **https://registro.br** antes de decidir:

- `certificadodigitalcdlbelem.com.br`
- `cdlcertificacaodigital.com.br`
- `certificadocdlbelem.com.br`
- `cdlbelemcertificados.com.br` (alternativa)

### 4.2 Conectando o domínio no Netlify

1. Registre o domínio escolhido em **registro.br**.
2. No painel do Netlify, vá em **Domain settings → Add a domain** e digite
   o domínio (ex.: `certificadodigitalcdlbelem.com.br`).
3. O Netlify mostra os registros DNS que você precisa cadastrar no
   registro.br (normalmente um `CNAME` para `www` e registros `A`/`ALIAS`
   para o domínio raiz — o próprio painel do Netlify explica exatamente
   quais valores usar para o seu caso).
4. Cadastre esses registros no painel DNS do registro.br.
5. Aguarde a propagação (de minutos a algumas horas). O Netlify emite o
   certificado HTTPS automaticamente (via Let's Encrypt) assim que o DNS
   propaga — **você não precisa comprar nem instalar nenhum certificado
   SSL manualmente**.
6. Depois disso, troque as ocorrências de `SEU-DOMINIO-AQUI.com.br` pelo
   domínio final nos arquivos `index.html`, `politica-de-privacidade.html`,
   `politica-de-cookies.html`, `termos-de-uso.html`, `robots.txt` e
   `sitemap.xml` (são as tags de SEO/Open Graph e o sitemap), e publique a
   pasta atualizada de novo.

## 5. O que confirmar antes de divulgar o site

1. **Números de WhatsApp**: aparecem em `index.html` (botão do topo, hero,
   preços, contato) e no rodapé — todos usam o mesmo número
   `5591984069203`. Procure por `EDITE AQUI` no arquivo para achar rápido
   cada trecho, ou use "Localizar e substituir" no bloco de notas.
2. **Telefones fixos e e-mail**: aparecem na seção de contato e no rodapé
   de cada página (procure `EDITE AQUI: telefones`).
3. **Preços**: seção "Valores" em `index.html` (procure `EDITE AQUI:
   valores dos planos`).
4. **Logo oficial**: hoje o cabeçalho usa um monograma simples criado para
   este projeto. Quando tiver o logotipo oficial em SVG ou PNG, substitua
   o bloco `<svg>...</svg>` dentro de `.logo` em cada página por
   `<img src="/logo.svg" alt="CDL Belém" height="34">` (coloque o arquivo
   do logo na mesma pasta).
5. **Imagem do hero**: hoje o hero usa uma ilustração vetorial própria
   (`images/certificado-digital-ilustracao.svg`) de um notebook e um cartão
   de certificado digital, no estilo azul/navy do site — não é uma foto.
   Isso evita problemas de nitidez (por ser vetor, fica sempre nítida em
   qualquer tamanho de tela) e evita o texto sobreposto que existia na foto
   original. Se um dia a CDL tiver uma foto profissional "limpa" (sem texto
   escrito em cima) do notebook/cartão/token, é só me avisar que eu troco
   pela foto real.
6. **Imagem para redes sociais** (`og-image.jpg`, 1200×630px): ainda não
   existe. Crie uma peça no padrão de marca e salve como
   `og-image.jpg` dentro desta mesma pasta.
7. **Horário de atendimento**: não estava na fonte original — adicione uma
   linha na seção de contato quando tiver essa informação.
8. **Revisão jurídica**: as páginas de Política de Privacidade, Cookies e
   Termos de Uso são modelos estruturais (veja o aviso destacado em cada
   uma) — precisam de validação de um advogado antes de publicar de fato.

## 6. Como editar o conteúdo no dia a dia

Não existe um "painel" separado nesta versão — o conteúdo está direto nos
arquivos `.html`. Para editar:

1. Abra o arquivo (ex.: `index.html`) com o Bloco de Notas ou qualquer
   editor de texto.
2. Use "Localizar" (Ctrl+F) para achar o texto que quer mudar (ex.: procure
   "R$ 120,00" para editar o preço do e-CPF).
3. Salve o arquivo.
4. Arraste a pasta inteira de novo em **app.netlify.com** (ou, se conectou
   um repositório Git, apenas suba a alteração — veja seção 7).

## 7. Alternativa: publicar direto do GitHub (deploy automático)

Se no futuro você quiser que qualquer edição publique sozinha (sem
arrastar pasta toda vez), é possível conectar este projeto a um
repositório no GitHub e o Netlify publica automaticamente a cada alteração
salva. Isso pode ser configurado depois, quando fizer sentido — não é
necessário para o site funcionar hoje.

## 8. Checklist de publicação

- [ ] Site publicado no Netlify e link `.netlify.app` testado no celular
- [ ] Notificação por e-mail do formulário configurada (seção 3)
- [ ] Números de WhatsApp e telefones confirmados pela CDL Belém
- [ ] Preços confirmados
- [ ] Logo oficial aplicado
- [ ] Imagem `og-image.jpg` adicionada
- [ ] Textos jurídicos revisados por advogado
- [ ] Domínio `.com.br` registrado e conectado (seção 4)
- [ ] Ocorrências de `SEU-DOMINIO-AQUI.com.br` substituídas pelo domínio real
- [ ] Teste em celular (iOS e Android), tablet e desktop
- [ ] Teste enviando o formulário de verdade, conferindo se o e-mail chega

## 9. Estrutura de arquivos

```
cdl-belem-netlify/
├── index.html                     # página principal (todas as seções)
├── politica-de-privacidade.html
├── politica-de-cookies.html
├── termos-de-uso.html
├── obrigado.html                  # página exibida após enviar o formulário
├── style.css                      # todo o visual do site
├── script.js                      # menu mobile, ano no rodapé
├── favicon.svg
├── _headers                       # cabeçalhos de segurança (lidos pelo Netlify)
├── robots.txt
└── sitemap.xml
```

---

### Por que esta versão é diferente da versão em Next.js que fiz antes?

Você teve dificuldades para rodar `npm install` no Windows (problemas de
permissão e caminho de pasta). Esta versão resolve isso: **não existe mais
nenhum comando pra rodar** — é só arrastar a pasta para o Netlify. A
desvantagem é que perdemos alguns recursos mais avançados da versão em
Next.js (como o arquivo único de configuração `site.config.ts` e o envio de
e-mail via API própria) — aqui a edição é feita direto no HTML, e o
formulário usa o recurso pronto do Netlify em vez de um servidor próprio.
Se no futuro você tiver mais confiança com o terminal (ou alguém técnico
por perto), a versão em Next.js continua disponível e pode ser retomada.
